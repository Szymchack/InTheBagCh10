﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InTheBag.Models
{
    public class Wishes
    {
        public int ID { get; set; }
        public string wish1 { get; set; }
        public string wish2 { get; set; }
        public string wish3 { get; set; }
    }
}
